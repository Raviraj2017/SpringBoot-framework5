package com.springfeamework5.SpringFramwork5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFramwork5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
